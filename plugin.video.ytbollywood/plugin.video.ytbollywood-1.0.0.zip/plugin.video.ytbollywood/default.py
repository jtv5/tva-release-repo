# -*- coding: utf-8 -*-
#------------------------------------------------------------
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.ytbollywood'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


YOUTUBE_CHANNEL_ID1 = "UCjDLPLMSVrRzFAv0gXb3rpw"
YOUTUBE_CHANNEL_ID2 = "UC_C__SsDmqlFJg4S2W9YliQ"
YOUTUBE_CHANNEL_ID3 = "UCY7tB-mpvlQeWgaCCS1Cmwg"
YOUTUBE_CHANNEL_ID4 = "UCOF23vGxkbhN4wl7ROrgXsA"
YOUTUBE_CHANNEL_ID5 = "UC2aBjYYDkwN5LLSB8957KZQ"
YOUTUBE_CHANNEL_ID6 = "UCs570zdFq_NNA5OcV8chnHw"
YOUTUBE_CHANNEL_ID7 = "UCvUctuMp58UD_kQtcWcNCjw"
YOUTUBE_CHANNEL_ID8 = "UCyoXW-Dse7fURq30EWl_CUA"
YOUTUBE_CHANNEL_ID9 = "UCcvSztuD2j7cmVhZcUh25kw"
YOUTUBE_CHANNEL_ID10 = "UC99AuktEF4zDnMrkwOPp63A"
YOUTUBE_CHANNEL_ID11 = "UCx90XU2NsIhcc-XR3mlzv8A"
YOUTUBE_CHANNEL_ID12 = "UCWi_65E_L8tQZ34C6wVAlpQ"

def run():
    params = plugintools.get_params()

    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"

    plugintools.close_item_list()


def main_list(params):
    plugintools.log("Bollywood.main_list "+repr(params))

plugintools.add_item(
    title="Bolly",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID1+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="CineBox",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID2+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="Goldmines Action",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID3+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="Goldmines Hindi",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID4+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="Goldmines Housefull",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID5+"/",
    thumbnail=icon,
    folder=True )                

plugintools.add_item(
    title="Goldmines Movies",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID6+"/",
    thumbnail=icon,
    folder=True )

plugintools.add_item(
    title="Goldmines Premiere",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID7+"/",
    thumbnail=icon,
    folder=True )
        
plugintools.add_item(
    title="Goldmines Telefilms",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID8+"/",
    thumbnail=icon,
    folder=True )
     
plugintools.add_item(
    title="Golden Collections",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID9+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="Movie World",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID10+"/",
    thumbnail=icon,
    folder=True )    

plugintools.add_item(
    title="Rajshri",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID11+"/",
    thumbnail=icon,
    folder=True )
    
plugintools.add_item(
    title="Venus",
    url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID12+"/",
    thumbnail=icon,
    folder=True )
       
run()

