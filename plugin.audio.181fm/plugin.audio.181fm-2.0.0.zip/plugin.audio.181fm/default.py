import urllib,urllib2,re,cookielib,string,HTMLParser
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
from t0mm0.common.addon import Addon
import datetime
import time
import os

ADDON=xbmcaddon.Addon(id='plugin.audio.181fm')
pars = HTMLParser.HTMLParser()
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.audio.181fm/resources/art', ''))
ADDON=xbmcaddon.Addon(id='plugin.audio.181fm')



def OPENURL(url):
        #print "openurl = " + url
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.75 Safari/537.1')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        link=pars.unescape(link)
        link=urllib.unquote(link)
        link=link.replace('\r','').replace('\n','').replace('\t','').replace('&nbsp;','')
        return link


def MAIN():
        link=OPENURL('http://www.181.fm/channellistmini.php')
        match = re.findall('700"><br>([^<]+)</font></td>(.+?)</table>', link)
        for name,url in match:
            name=name.replace('/','&')
            addDir(name,url,1,art+name+".png")
    

def LIST(mname,murl):
        thumb=art+"%s.png"%(mname)
        print "kk "+thumb
        match = re.compile('<a STYLE="text-decoration:none" href="([^"]+)" class="left_link">([^<]+)</a></font></td>').findall(murl)
        for url,name in match:
            addPlay(name,url,2,thumb)

def LINK(name,url):
        link=OPENURL(url)
        source = re.findall('<REF HREF="([^"]+)"/>', link)
        for stream_url in source:
                match = re.compile('relay').findall(stream_url)
                print match
                if len(match)>0:
                        stream=stream_url
                else:
                        stream=stream_url
        pl = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        pl.clear()    
        pl.add(stream)
        xbmc.Player().play(pl)
        xbmc.executebuiltin("Container.Refresh")
        

def addPlay(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage='', thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image',art+"fanart.jpg")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok


def addSearchDir(name, mode,iconimage):
    #thumbnail = 'DefaultPlaylist.png'
    u         = sys.argv[0] + "?mode=" + str(mode)        
    liz       = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
    liz.setProperty('fanart_image',art+"fanart.jpg")
    xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = False)


def addDir(name, url, mode, thumbImage):

        u  = sys.argv[0]

        u += "?url="  + urllib.quote_plus(url)
        u += "&mode=" + str(mode)
        u += "&name=" + urllib.quote_plus(name)

        liz = xbmcgui.ListItem(name, iconImage='', thumbnailImage=thumbImage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        liz.setProperty('fanart_image',art+"fanart.jpg")

        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=True)



def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "Name: "+str(name)



if mode==None or url==None or len(url)<1:
        MAIN()
       
elif mode==1:
        LIST(name,url)
        
elif mode==2:
        LINK(name,url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
